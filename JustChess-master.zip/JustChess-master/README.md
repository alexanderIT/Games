# JustChess
Console Chess Game for the OOP course at Telerik Academy
