﻿namespace JustChess.Common.Console
{
    public class ConsoleConstants
    {
        public const int CharactersPerRowPerBoardSquare = 9;
        public const int CharactersPerColPerBoardSquare = 9;

        public const int ConsoleRowForPlayerIO = 0;
    }
}
