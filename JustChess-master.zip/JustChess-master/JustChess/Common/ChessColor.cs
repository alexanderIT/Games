﻿namespace JustChess.Common
{
    public enum ChessColor
    {
        Black,
        White,
        Brown
    }
}
