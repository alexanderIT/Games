﻿namespace JustChess
{
    public class EntryPoint
    {
        public static void Main()
        {
            ChessFacade.Start();
        }
    }
}
